<template>
  <br><br>
  <form class="content-border">
    <img src="../assets/bbq-chicken-with-chakalaka-1-825x510.png" class="img-fluid rounded-start" alt="...">
    <br><br>
    <h5>Whats inside Ready Recipes Delivery Boxs?</h5><br>
    <p class="card-text"><strong>Fresh,quality:</strong>Crisp vegetables and ripe fruits selected to bring vibrant
      flavors to every dish.</p>
    <p><strong>Simple recipe cards:</strong> Step-by-step recipes with nutrional information that takes the
      guesswork out of cooking,no matter your skill level</p>
    <p><strong>Top-notch protein:</strong> From succulent chicken to lean beef,we deliver the best to elevate your
      meal.</p>
    <p><strong>Customizable add-ons:</strong> Choose from a range of toppings, sauces, and extras to make your
      meal truly unique and delicious</p>

  </form>
</template>
<style>
.content-border {
  display: inline-block;
  /* Ensures the border only wraps around the content */
  border: 5px solid black;
  padding: 15px 20px;
  border-radius: 15px;
}

h5 {
  text-decoration: underline;
}

p {
  display: list-item;
  list-style-type: disc;
  /* Adds a bullet point */
  margin-left: 20px;
  /* Indent to align properly */
}
</style>